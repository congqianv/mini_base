Component({
  /**
   * 组件的属性列表
   */
  properties: {
    pageIndex: {
      type: Number,
      value: 0
    },
    background: {
      type: String,
      value: '#fff'
    }
  },

  /**
   * 组件的初始数据
   */
  data: {
    tabList: [
      {
        name: '商城',
        value: 'store',
        page: 'index'
      },
      {
        name: '会员',
        value: 'member',
        page: 'member'
      },
      {
        name: '购物车',
        value: 'cart',
        page: 'cart'
      },
      {
        name: '我的',
        value: 'mine',
        page: 'mine'
      }
    ],
    detail: {},
    lastTouchStamp: 0
  },

  /**
   * 组件的方法列表
   */
  methods: {
    handleChange (e) {
      let { index, page } = e.currentTarget.dataset;
      if (index == this.data.pageIndex) {
        this.doubleClick(e)
        return
      }

      let detail = e.currentTarget.dataset;
      this.setData({
        detail
      })
      this.triggerEvent('change', {
        detail
      }, {})
      wx.switchTab({
        url: `../${page}/${page}`
      })
    },

    doubleClick (e) {
      let { lastTouchStamp } = this.data
      if (e.timeStamp - lastTouchStamp < 300 && e.timeStamp - lastTouchStamp > 0) {
        // 双击，进入
        wx.pageScrollTo({
          scrollTop: 0
        })
      }
      this.setData({
        lastTouchStamp: e.timeStamp
      })
    }
  }
})
