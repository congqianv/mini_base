const app = getApp()

Component({
  properties: {

  },
  observers: {

  },
  /**
   * 这里是一些组件内部数据
   */
  data: {
    showMask: false,
    content: '',
    isLoading: false
  },

  methods: {
    doNothing() {
      // doNothing
    },

    showToast({ title, mask }) {
      this.setData({
        content: title,
        showMask: mask
      })
    },

    clearToast() {
      this.setData({
        content: '',
        showMask: false
      })
    },

    showLoading({ title, mask }) {
      this.setData({
        isLoading: true
      })
      console.log(title, mask)
      this.showToast({ title, mask })
    },

    hideLoading () {
      this.setData({
        content: '',
        isLoading: false,
        showMask: false
      })
    }
  }
})
