var timer = ''

function getPage() {
  const pages = getCurrentPages();
  let page = pages[pages.length - 1];
  let cp = page.selectComponent('#my-toast')
  return cp
}

function showToast({ title, duration = 3000, mask = false }) {
  if (!title) {
    throw Error('title can not be undefined')
  }
  let cp = getPage()
  cp.showToast({
    title,
    mask
  })
  clearToast(duration)
}

function clearToast(duration) {
  let cp = getPage()
  clearTimeout(timer)
  timer = setTimeout(() => {
    cp.clearToast()
  }, duration);
}

function showLoading(obj) {
  if (!obj) {
    obj = {
      title: '',
      mask: true
    }
  }
  let { title, mask = true } = obj
  console.log(obj)
  let cp = getPage()
  cp.showLoading({
    title,
    mask
  })
}

function hideLoading () {
  let cp = getPage()
  cp.hideLoading()
}

module.exports = {
  Toast: {
    showToast,
    showLoading,
    hideLoading
  }
}