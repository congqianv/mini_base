const app = getApp()

Component({
  options: {
    styleIsolation: 'apply-shared'
  },
  properties: {
    title: {
      type: String,
      value: ''
    },
    label: {
      type: String,
      value: ''
    },
    rightLabel: {
      type: String,
      value: ''
    },
    showBorder: {
      type: Boolean,
      value: false
    },
    hideArrow: {
      type: Boolean,
      value: false
    },
    titleColor: {
      type: String,
      value: ''
    },
    labelStyle: {
      type: String,
      value: ''
    },
    rightLabelStyle: {
      type: String,
      value: ''
    },
    cusStyle: {
      type: String,
      value: ''
    }
  },
  /**
   * 这里是一些组件内部数据
   */
  data: {

  },

  methods: {
    onTap () {
      this.triggerEvent('onTap', true)
    },

    onTapMore () {
      this.triggerEvent('onTapMore', true)
    }
  }
})
