const app = getApp()

Component({
  properties: {
    stepList: {
      type: Array,
      value: []
    },
    currentStep: {
      type: Number,
      value: 0
    }
  },
  /**
   * 这里是一些组件内部数据
   */
  data: {

  },

  methods: {

  }
})
