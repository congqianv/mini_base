const app = getApp()

Component({
  properties: {
    productList: {
      type: Array,
      value: []
    },
    disabled: {
      type: Boolean,
      value: false
    }
  },
  /**
   * 这里是一些组件内部数据
   */
  data: {

  },

  methods: {
    handleTouchStart (e) {
      if (this.data.disabled) return
      // 获取滑动的起始位置
      this.startX = e.touches[0].pageX
    },

    handleTouchEnd (e) {
      if (this.data.disabled) return
      let { index } = e.currentTarget.dataset
      // e.changedTouches[0].pageX < this.startX 向左划动
      // e.changedTouches[0].pageX > this.startX 向右划动
      if (e.changedTouches[0].pageX < this.startX && e.changedTouches[0].pageX - this.startX <= -40) {
        this.showDeleteBtn(index)
      } else if (e.changedTouches[0].pageX > this.startX && e.changedTouches[0].pageX - this.startX < 40) {
        this.showDeleteBtn(index)
      } else {
        this.hideDeleteBtn(index)
      }
    },

    handleMovableChange (e) {
      if (this.data.disabled) return
      let { index } = e.currentTarget.dataset
      if (e.detail.source === 'friction') {
        if (e.detail.x < -40) {
          this.showDeleteBtn(index)
        } else {
          this.hideDeleteBtn(index)
        }
      } else if (e.detail.source === 'out-of-bounds' && e.detail.x === 0) {
        this.hideDeleteButton(index)
      }
    },

    showDeleteBtn (index) {
      this.setXOffset(index, -100)
    },

    hideDeleteBtn (index) {
      this.setXOffset(index, 0)
    },

    setXOffset (index, offset) {
      let { productList } = this.data
      productList[index]['xOffset'] = offset
      this.setData({
        productList
      })
    },

    handleSelect (e) {
      let { index } = e.currentTarget.dataset
      this.triggerEvent('handleSelect', index)
    },

    handleGoodsNum (e) {
      let { type, index } = e.currentTarget.dataset
      this.triggerEvent('handleGoodsNum', {type, index})
    },

    handleDelete (e) {
      let { index } = e.currentTarget.dataset
      this.triggerEvent('handleDelete', index)
    },

    onTapItem (e) {
      let { item } = e.currentTarget.dataset
      this.triggerEvent('onTapItem', item)
    }
  }
})
