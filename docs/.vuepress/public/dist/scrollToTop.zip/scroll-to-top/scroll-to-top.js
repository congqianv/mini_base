const app = getApp()

Component({
  properties: {
    showScrollToTop: {
      type: Boolean,
      value: false
    }
  },
  /**
   * 这里是一些组件内部数据
   */
  data: {

  },

  methods: {
    scrollToTop () {
      wx.pageScrollTo({
        scrollTop: 0
      })
    }
  }
})
